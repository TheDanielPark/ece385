danielp7 | masakis2

We expect 5 points. 
The ball never goes diagonal or goes through the screen even if we change direction in the corners & hold a direction and keep hitting a wall.
It does not go through the wall but it just keep bouncing and sticking to the wall. 
The keyboard press shows up on the FPGA and it shows up when pressed and not released.
The ball responds to the keyboard input very well.
We checked with the TA in office hours for edge cases and fixed it glitching through a wall when a key was held down and pushed into the wall.
we also fixed the glitch of it hitting a wall and it going in both x and y directions making it diagonal.
Both instances are no longer reproducable. 

5/5 points from our end. 